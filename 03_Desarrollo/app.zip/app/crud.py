import random
import string
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import extract
from . import models, schemas, ai_module

def generate_codigo_seguimiento() -> str:
    num = "".join(random.choices(string.digits, k=4))
    return f"TCK-2026-{num}"

def get_cliente_by_email(db: Session, email: str):
    return db.query(models.Cliente).filter(models.Cliente.correo_electronico == email).first()

def create_or_update_cliente(db: Session, cliente: schemas.ClienteCreate):
    db_cliente = get_cliente_by_email(db, cliente.correo_electronico)
    if db_cliente:
        db_cliente.nombre_completo = cliente.nombre_completo
        if cliente.telefono:
            db_cliente.telefono = cliente.telefono
        if cliente.empresa_organizacion:
            db_cliente.empresa_organizacion = cliente.empresa_organizacion
    else:
        db_cliente = models.Cliente(
            nombre_completo=cliente.nombre_completo,
            correo_electronico=cliente.correo_electronico,
            telefono=cliente.telefono,
            empresa_organizacion=cliente.empresa_organizacion
        )
        db.add(db_cliente)
    db.commit()
    db.refresh(db_cliente)
    return db_cliente

def create_ticket_with_ai(db: Session, ticket_data: schemas.TicketCreate):
    # 1. Get or Create/Update Cliente with exact dynamic values
    cliente_in = schemas.ClienteCreate(
        nombre_completo=ticket_data.nombre_cliente,
        correo_electronico=ticket_data.correo_cliente,
        telefono=ticket_data.telefono,
        empresa_organizacion=ticket_data.empresa
    )
    cliente = create_or_update_cliente(db, cliente_in)

    # 2. Generate Tracking Code
    codigo = generate_codigo_seguimiento()
    while db.query(models.Ticket).filter(models.Ticket.codigo_seguimiento == codigo).first():
        codigo = generate_codigo_seguimiento()

    # 3. Fetch Soluciones for AI matching
    soluciones = db.query(models.Solucion).all()
    soluciones_list = [
        {
            "id_solucion": s.id_solucion,
            "titulo": s.titulo,
            "contenido_solucion": s.contenido_solucion,
            "categoria": s.categoria,
            "palabras_clave": s.palabras_clave
        }
        for s in soluciones
    ]

    # 4. Run AI Analysis
    ai_result = ai_module.analyze_and_suggest(ticket_data.titulo, ticket_data.descripcion, soluciones_list)

    # 5. Respect client's selected category if present, otherwise use AI category
    cat_final = ticket_data.categoria_preliminar if (ticket_data.categoria_preliminar and ticket_data.categoria_preliminar != "General") else (ai_result["categoria_sugerida"] or "General")

    # 6. Create Ticket in DB with exact user inputs
    db_ticket = models.Ticket(
        codigo_seguimiento=codigo,
        id_cliente=cliente.id_cliente,
        titulo=ticket_data.titulo,
        descripcion=ticket_data.descripcion,
        categoria_preliminar=cat_final,
        prioridad=ai_result["prioridad_sugerida"],
        estado="Abierto"
    )
    db.add(db_ticket)
    db.commit()
    db.refresh(db_ticket)

    # 7. Create SugerenciaIA entry
    db_sugerencia = models.SugerenciaIA(
        id_ticket=db_ticket.id_ticket,
        prioridad_sugerida=ai_result["prioridad_sugerida"],
        categoria_sugerida=ai_result["categoria_sugerida"],
        respuesta_sugerida=ai_result["respuesta_sugerida"],
        score_confianza=ai_result["score_confianza"]
    )
    db.add(db_sugerencia)
    db.commit()
    db.refresh(db_sugerencia)

    return db_ticket

def get_ticket_by_codigo(db: Session, codigo: str):
    return db.query(models.Ticket).filter(models.Ticket.codigo_seguimiento == codigo).first()

def get_ticket_by_id(db: Session, id_ticket: int):
    return db.query(models.Ticket).filter(models.Ticket.id_ticket == id_ticket).first()

def get_tickets(db: Session, estado: str = None, prioridad: str = None):
    query = db.query(models.Ticket)
    if estado and estado != "Todos":
        query = query.filter(models.Ticket.estado == estado)
    if prioridad and prioridad != "Todas":
        query = query.filter(models.Ticket.prioridad == prioridad)
    return query.order_by(models.Ticket.fecha_creacion.desc()).all()

def asignar_ticket(db: Session, id_ticket: int, id_agente: int):
    ticket = get_ticket_by_id(db, id_ticket)
    if ticket:
        ticket.id_agente_asignado = id_agente
        if ticket.estado == "Abierto":
            ticket.estado = "En Proceso"
        ticket.fecha_actualizacion = datetime.utcnow()
        db.commit()
        db.refresh(ticket)
    return ticket

def responder_ticket(db: Session, id_ticket: int, respuesta: str, nuevo_estado: str):
    ticket = get_ticket_by_id(db, id_ticket)
    if ticket:
        ticket.respuesta_oficial = respuesta
        ticket.estado = nuevo_estado
        ticket.fecha_actualizacion = datetime.utcnow()
        db.commit()
        db.refresh(ticket)
    return ticket

def get_soluciones(db: Session, categoria: str = None, query: str = None):
    q = db.query(models.Solucion)
    if categoria:
        q = q.filter(models.Solucion.categoria == categoria)
    if query:
        q = q.filter(models.Solucion.titulo.contains(query) | models.Solucion.palabras_clave.contains(query))
    return q.all()

def create_solucion(db: Session, solucion: schemas.SolucionCreate):
    db_sol = models.Solucion(
        titulo=solucion.titulo,
        contenido_solucion=solucion.contenido_solucion,
        categoria=solucion.categoria,
        palabras_clave=solucion.palabras_clave,
        id_autor=solucion.id_autor,
        id_ticket_origen=solucion.id_ticket_origen
    )
    db.add(db_sol)
    db.commit()
    db.refresh(db_sol)
    return db_sol

def get_dashboard_metrics(db: Session):
    total = db.query(models.Ticket).count()
    abiertos = db.query(models.Ticket).filter(models.Ticket.estado == "Abierto").count()
    en_proceso = db.query(models.Ticket).filter(models.Ticket.estado == "En Proceso").count()
    resueltos = db.query(models.Ticket).filter(models.Ticket.estado.in_(["Resuelto", "Cerrado"])).count()
    
    p_alta = db.query(models.Ticket).filter(models.Ticket.prioridad == "Alta").count()
    p_media = db.query(models.Ticket).filter(models.Ticket.prioridad == "Media").count()
    p_baja = db.query(models.Ticket).filter(models.Ticket.prioridad == "Baja").count()
    
    return {
        "total_tickets": total,
        "tickets_abiertos": abiertos,
        "tickets_en_proceso": en_proceso,
        "tickets_resueltos": resueltos,
        "prioridad_alta_ia": p_alta,
        "prioridad_media_ia": p_media,
        "prioridad_baja_ia": p_baja,
        "tiempo_promedio_respuesta_minutos": 12.5,
        "efectividad_sugerencia_ia_porcentaje": 91.2
    }

def get_monthly_report_data(db: Session, mes: int, anio: int):
    # Filter tickets by month and year
    tickets_query = db.query(models.Ticket).filter(
        extract('month', models.Ticket.fecha_creacion) == mes,
        extract('year', models.Ticket.fecha_creacion) == anio
    )
    tickets = tickets_query.all()
    total = len(tickets)
    
    resueltos = sum(1 for t in tickets if t.estado in ["Resuelto", "Cerrado"])
    abiertos = sum(1 for t in tickets if t.estado == "Abierto")
    en_proceso = sum(1 for t in tickets if t.estado == "En Proceso")
    
    alta = sum(1 for t in tickets if t.prioridad == "Alta")
    media = sum(1 for t in tickets if t.prioridad == "Media")
    baja = sum(1 for t in tickets if t.prioridad == "Baja")
    
    agentes = db.query(models.UsuarioAgente).all()
    agentes_perf = []
    for a in agentes:
        cnt = sum(1 for t in tickets if t.id_agente_asignado == a.id_agente)
        agentes_perf.append({
            "id_agente": a.id_agente,
            "nombre": a.nombre_completo,
            "rol": a.rol,
            "atendidos": cnt
        })
        
    return {
        "mes": mes,
        "anio": anio,
        "periodo": f"{anio}-{mes:02d}",
        "total_tickets": total,
        "tickets_resueltos": resueltos,
        "tickets_abiertos": abiertos,
        "tickets_en_proceso": en_proceso,
        "prioridad_alta": alta,
        "prioridad_media": media,
        "prioridad_baja": baja,
        "agentes_perf": agentes_perf,
        "tickets_lista": tickets
    }
