import os
import csv
import io
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, Request, Form, Query, status
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.database import get_db, Base, engine
from app import models, schemas, crud, ai_module

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Portal de Atención al Cliente 24/7 con IA",
    description="API Backend y Portal Web de Servicio Asistido por Inteligencia Artificial",
    version="1.0.0"
)

TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

# -------------------------------------------------------------
# REST API ENDPOINTS
# -------------------------------------------------------------

@app.post("/api/v1/tickets/", response_model=schemas.TicketResponse, status_code=status.HTTP_201_CREATED, tags=["Tickets 24/7"])
def api_crear_ticket(ticket_in: schemas.TicketCreate, db: Session = Depends(get_db)):
    ticket = crud.create_ticket_with_ai(db, ticket_in)
    return ticket

@app.get("/api/v1/tickets/seguimiento/{codigo_seguimiento}", response_model=schemas.TicketResponse, tags=["Tickets 24/7"])
def api_consultar_seguimiento(codigo_seguimiento: str, db: Session = Depends(get_db)):
    ticket = crud.get_ticket_by_codigo(db, codigo_seguimiento)
    if not ticket:
        raise HTTPException(status_code=404, detail="Código de ticket no encontrado")
    return ticket

@app.post("/api/v1/ia/analizar-ticket/{id_ticket}", response_model=schemas.SugerenciaIAResponse, tags=["Inteligencia Artificial"])
def api_analizar_ticket_ia(id_ticket: int, db: Session = Depends(get_db)):
    ticket = crud.get_ticket_by_id(db, id_ticket)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    
    soluciones = crud.get_soluciones(db)
    sol_list = [{"titulo": s.titulo, "contenido_solucion": s.contenido_solucion, "categoria": s.categoria, "palabras_clave": s.palabras_clave} for s in soluciones]
    
    res = ai_module.analyze_and_suggest(ticket.titulo, ticket.descripcion, sol_list)
    
    sugerencia = db.query(models.SugerenciaIA).filter(models.SugerenciaIA.id_ticket == id_ticket).first()
    if not sugerencia:
        sugerencia = models.SugerenciaIA(
            id_ticket=id_ticket,
            prioridad_sugerida=res["prioridad_sugerida"],
            categoria_sugerida=res["categoria_sugerida"],
            respuesta_sugerida=res["respuesta_sugerida"],
            score_confianza=res["score_confianza"]
        )
        db.add(sugerencia)
    else:
        sugerencia.prioridad_sugerida = res["prioridad_sugerida"]
        sugerencia.categoria_sugerida = res["categoria_sugerida"]
        sugerencia.respuesta_sugerida = res["respuesta_sugerida"]
        sugerencia.score_confianza = res["score_confianza"]
    
    db.commit()
    db.refresh(sugerencia)
    return sugerencia

@app.get("/api/v1/agente/tickets/", response_model=List[schemas.TicketResponse], tags=["Bandeja Agentes"])
def api_listar_tickets_agente(
    estado: Optional[str] = None,
    prioridad: Optional[str] = None,
    db: Session = Depends(get_db)
):
    return crud.get_tickets(db, estado=estado, prioridad=prioridad)

@app.put("/api/v1/agente/tickets/{id_ticket}/asignar", tags=["Bandeja Agentes"])
def api_asignar_ticket(id_ticket: int, datos: schemas.TicketAsignar, db: Session = Depends(get_db)):
    ticket = crud.asignar_ticket(db, id_ticket, datos.id_agente)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    return {"id_ticket": ticket.id_ticket, "id_agente_asignado": ticket.id_agente_asignado, "estado": ticket.estado, "mensaje": "Ticket asignado exitosamente."}

@app.put("/api/v1/agente/tickets/{id_ticket}/responder", tags=["Bandeja Agentes"])
def api_responder_ticket(id_ticket: int, datos: schemas.TicketResponder, db: Session = Depends(get_db)):
    ticket = crud.responder_ticket(db, id_ticket, datos.respuesta_oficial, datos.nuevo_estado)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado")
    return {"id_ticket": ticket.id_ticket, "estado": ticket.estado, "respuesta_oficial": ticket.respuesta_oficial, "mensaje": "Respuesta enviada y ticket actualizado."}

@app.get("/api/v1/soluciones/", response_model=List[schemas.SolucionResponse], tags=["Base de Conocimiento"])
def api_listar_soluciones(categoria: Optional[str] = None, q: Optional[str] = None, db: Session = Depends(get_db)):
    return crud.get_soluciones(db, categoria=categoria, query=q)

@app.post("/api/v1/soluciones/", response_model=schemas.SolucionResponse, status_code=status.HTTP_201_CREATED, tags=["Base de Conocimiento"])
def api_crear_solucion(solucion_in: schemas.SolucionCreate, db: Session = Depends(get_db)):
    return crud.create_solucion(db, solucion_in)

@app.get("/api/v1/admin/dashboard", tags=["Dashboard & Reportes"])
def api_dashboard_metrics(db: Session = Depends(get_db)):
    return crud.get_dashboard_metrics(db)

@app.get("/api/v1/admin/reportes/mensual", tags=["Dashboard & Reportes"])
def api_reporte_mensual(mes: int = Query(8, ge=1, le=12), anio: int = Query(2026, ge=2020), db: Session = Depends(get_db)):
    rep = crud.get_monthly_report_data(db, mes, anio)
    return {
        "periodo": rep["periodo"],
        "total_tickets_mes": rep["total_tickets"],
        "tickets_resueltos_exitosamente": rep["tickets_resueltos"],
        "tickets_pendientes": rep["tickets_abiertos"] + rep["tickets_en_proceso"],
        "promedio_tiempo_resolucion_horas": 1.2,
        "desempeno_agentes": rep["agentes_perf"],
        "resumen_ejecutivo": f"El portal de soporte 24/7 procesó {rep['total_tickets']} solicitudes durante el período {rep['periodo']}. Las sugerencias de IA aceleraron la atención."
    }

# -------------------------------------------------------------
# WEB UI ROUTES
# -------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def page_login(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.get("/crear-solicitud", response_class=HTMLResponse)
def page_crear_solicitud(request: Request):
    return templates.TemplateResponse(request=request, name="crear_solicitud.html", context={"mensaje_exito": None})

@app.post("/crear-solicitud", response_class=HTMLResponse)
def page_crear_solicitud_submit(
    request: Request,
    nombre_cliente: str = Form(...),
    correo_cliente: str = Form(...),
    telefono: str = Form(""),
    empresa: str = Form(""),
    titulo: str = Form(...),
    descripcion: str = Form(...),
    categoria_preliminar: str = Form("General"),
    db: Session = Depends(get_db)
):
    ticket_in = schemas.TicketCreate(
        nombre_cliente=nombre_cliente,
        correo_cliente=correo_cliente,
        telefono=telefono,
        empresa=empresa,
        titulo=titulo,
        descripcion=descripcion,
        categoria_preliminar=categoria_preliminar
    )
    ticket = crud.create_ticket_with_ai(db, ticket_in)
    return templates.TemplateResponse(request=request, name="crear_solicitud.html", context={
        "mensaje_exito": f"¡Ticket registrado exitosamente 24/7! Tu código de seguimiento es: {ticket.codigo_seguimiento}",
        "ticket": ticket
    })

@app.get("/mis-tickets", response_class=HTMLResponse)
def page_mis_tickets(request: Request, codigo: Optional[str] = None, db: Session = Depends(get_db)):
    ticket = None
    error = None
    if codigo:
        ticket = crud.get_ticket_by_codigo(db, codigo.strip())
        if not ticket:
            error = f"No se encontró ninguna solicitud con el código '{codigo}'."
    return templates.TemplateResponse(request=request, name="mis_tickets.html", context={"ticket": ticket, "codigo": codigo or "", "error": error})

@app.get("/agente/tickets", response_class=HTMLResponse)
def page_lista_tickets(request: Request, estado: Optional[str] = "Todos", prioridad: Optional[str] = "Todas", db: Session = Depends(get_db)):
    tickets = crud.get_tickets(db, estado=estado, prioridad=prioridad)
    return templates.TemplateResponse(request=request, name="lista_tickets.html", context={
        "tickets": tickets,
        "estado_filtro": estado,
        "prioridad_filtro": prioridad
    })

@app.get("/agente/tickets/{id_ticket}", response_class=HTMLResponse)
def page_detalle_ticket(request: Request, id_ticket: int, db: Session = Depends(get_db)):
    ticket = crud.get_ticket_by_id(db, id_ticket)
    if not ticket:
        return RedirectResponse(url="/agente/tickets")
    
    agentes = db.query(models.UsuarioAgente).all()
    sugerencia = ticket.sugerencia_ia
    if not sugerencia:
        soluciones = crud.get_soluciones(db)
        sol_list = [{"titulo": s.titulo, "contenido_solucion": s.contenido_solucion, "categoria": s.categoria, "palabras_clave": s.palabras_clave} for s in soluciones]
        res = ai_module.analyze_and_suggest(ticket.titulo, ticket.descripcion, sol_list)
        sugerencia = models.SugerenciaIA(
            id_ticket=ticket.id_ticket,
            prioridad_sugerida=res["prioridad_sugerida"],
            categoria_sugerida=res["categoria_sugerida"],
            respuesta_sugerida=res["respuesta_sugerida"],
            score_confianza=res["score_confianza"]
        )
        db.add(sugerencia)
        db.commit()
        db.refresh(sugerencia)

    return templates.TemplateResponse(request=request, name="detalle_ticket.html", context={
        "ticket": ticket,
        "sugerencia": sugerencia,
        "agentes": agentes
    })

@app.post("/agente/tickets/{id_ticket}/responder", response_class=HTMLResponse)
def page_detalle_ticket_responder(
    request: Request,
    id_ticket: int,
    respuesta_oficial: str = Form(...),
    nuevo_estado: str = Form("Resuelto"),
    guardar_solucion: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    ticket = crud.responder_ticket(db, id_ticket, respuesta_oficial, nuevo_estado)
    if guardar_solucion and ticket:
        admin = db.query(models.UsuarioAgente).first()
        sol_in = schemas.SolucionCreate(
            titulo=f"Solución: {ticket.titulo}",
            contenido_solucion=respuesta_oficial,
            categoria=ticket.categoria_preliminar,
            palabras_clave=f"{ticket.categoria_preliminar}, {ticket.titulo}",
            id_autor=admin.id_agente if admin else 1,
            id_ticket_origen=ticket.id_ticket
        )
        crud.create_solucion(db, sol_in)
    return RedirectResponse(url=f"/agente/tickets/{id_ticket}", status_code=status.HTTP_303_SEE_OTHER)

@app.post("/agente/tickets/{id_ticket}/asignar", response_class=HTMLResponse)
def page_detalle_ticket_asignar(
    request: Request,
    id_ticket: int,
    id_agente: int = Form(...),
    db: Session = Depends(get_db)
):
    crud.asignar_ticket(db, id_ticket, id_agente)
    return RedirectResponse(url=f"/agente/tickets/{id_ticket}", status_code=status.HTTP_303_SEE_OTHER)

@app.get("/admin/dashboard", response_class=HTMLResponse)
def page_dashboard(request: Request, db: Session = Depends(get_db)):
    metrics = crud.get_dashboard_metrics(db)
    recent_tickets = crud.get_tickets(db)[:5]
    return templates.TemplateResponse(request=request, name="dashboard.html", context={
        "metrics": metrics,
        "recent_tickets": recent_tickets
    })

@app.get("/admin/reportes", response_class=HTMLResponse)
def page_reportes(request: Request, mes: int = 8, anio: int = 2026, db: Session = Depends(get_db)):
    rep = crud.get_monthly_report_data(db, mes, anio)
    return templates.TemplateResponse(request=request, name="reportes.html", context={
        "reporte": rep,
        "mes": mes,
        "anio": anio
    })

@app.get("/admin/reportes/exportar-csv")
def page_exportar_reporte_csv(mes: int = 8, anio: int = 2026, db: Session = Depends(get_db)):
    rep = crud.get_monthly_report_data(db, mes, anio)
    output = io.StringIO()
    writer = csv.writer(output)
    
    writer.writerow(["REPORTE MENSUAL DE GESTIÓN DE ATENCIÓN AL CLIENTE 24/7 CON IA"])
    writer.writerow(["Período", rep["periodo"]])
    writer.writerow(["Total Tickets Mes", rep["total_tickets"]])
    writer.writerow(["Tickets Resueltos", rep["tickets_resueltos"]])
    writer.writerow(["Tickets Abiertos", rep["tickets_abiertos"]])
    writer.writerow(["Tickets en Proceso", rep["tickets_en_proceso"]])
    writer.writerow(["Prioridad Alta (IA)", rep["prioridad_alta"]])
    writer.writerow(["Prioridad Media (IA)", rep["prioridad_media"]])
    writer.writerow(["Prioridad Baja (IA)", rep["prioridad_baja"]])
    writer.writerow([])
    
    writer.writerow(["LISTADO DETALLADO DE TICKETS DEL MES"])
    writer.writerow(["Código", "Título", "Categoría", "Prioridad IA", "Estado", "Cliente", "Fecha Creación"])
    for t in rep["tickets_lista"]:
        writer.writerow([
            t.codigo_seguimiento,
            t.titulo,
            t.categoria_preliminar,
            t.prioridad,
            t.estado,
            t.cliente.nombre_completo if t.cliente else "",
            t.fecha_creacion.strftime('%Y-%m-%d %H:%M:%S')
        ])
        
    output.seek(0)
    filename = f"reporte_mensual_{anio}_{mes:02d}.csv"
    headers = {"Content-Disposition": f"attachment; filename={filename}"}
    return Response(content=output.getvalue(), media_type="text/csv", headers=headers)

@app.get("/admin/clientes", response_class=HTMLResponse)
def page_clientes(request: Request, db: Session = Depends(get_db)):
    clientes = db.query(models.Cliente).all()
    return templates.TemplateResponse(request=request, name="clientes.html", context={
        "clientes": clientes
    })
