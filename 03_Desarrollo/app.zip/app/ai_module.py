import os
import re
from typing import Dict, Any, List

def analyze_and_suggest(titulo: str, descripcion: str, soluciones_kb: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyzes ticket text to assign priority (Alta, Media, Baja), category,
    and generate a suggested response based on OpenAI or Smart Rule-based NLP.
    """
    openai_key = os.getenv("OPENAI_API_KEY")
    
    # Text normalization for analysis
    text_full = f"{titulo} {descripcion}".lower()
    
    # Priority rules analysis
    high_keywords = ["urgente", "crítico", "caído", "caido", "bloqueo", "error 500", "no funciona", "inacesible", "falla grave", "seguridad", "hack", "violación"]
    medium_keywords = ["lento", "demora", "configuración", "configuracion", "permiso", "acceso", "cuenta", "modificar", "duda", "problema"]
    
    prioridad = "Baja"
    if any(k in text_full for k in high_keywords):
        prioridad = "Alta"
    elif any(k in text_full for k in medium_keywords):
        prioridad = "Media"
        
    # Category detection
    categoria = "Soporte Técnico"
    if any(k in text_full for k in ["acceso", "login", "contraseña", "clave", "usuario", "perfil"]):
        categoria = "Acceso y Cuentas"
    elif any(k in text_full for k in ["caído", "caido", "servidor", "red", "conexion", "conexión", "timeout"]):
        categoria = "Conectividad y Servidores"
    elif any(k in text_full for k in ["pago", "factura", "cobro", "tarjeta", "valor"]):
        categoria = "Facturación y Pagos"
        
    # Semantic Search in Knowledge Base
    best_match = None
    highest_score = 0
    
    for sol in soluciones_kb:
        sol_text = f"{sol.get('titulo', '')} {sol.get('palabras_clave', '')} {sol.get('contenido_solucion', '')}".lower()
        score = 0
        for word in text_full.split():
            if len(word) > 3 and word in sol_text:
                score += 1
        if score > highest_score:
            highest_score = score
            best_match = sol

    # Generate response draft
    if best_match:
        respuesta = (
            f"Estimado usuario,\n\nDe acuerdo con la información de nuestra base de conocimiento "
            f"para problemas de '{best_match.get('categoria', 'soporte')}', le sugerimos los siguientes pasos:\n\n"
            f"{best_match.get('contenido_solucion')}\n\n"
            f"Quedamos atentos a la confirmación de solución de su requerimiento."
        )
        score_confianza = min(0.98, 0.70 + (highest_score * 0.05))
    else:
        respuesta = (
            f"Estimado usuario,\n\nHemos analizado su solicitud respecto a '{titulo}'. "
            f"Se ha identificado una prioridad {prioridad}. Un agente de soporte revisará los detalles "
            f"de su caso de forma prioritaria para brindarle una solución completa."
        )
        score_confianza = 0.88

    return {
        "prioridad_sugerida": prioridad,
        "categoria_sugerida": categoria,
        "respuesta_sugerida": respuesta,
        "score_confianza": round(score_confianza, 2)
    }
